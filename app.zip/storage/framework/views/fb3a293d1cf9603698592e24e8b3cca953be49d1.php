<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RASH</title>
    <style>
        body {
            font-size: 12px;
        }

        h3 {
            text-align: center;
            margin-top: 0px;
            margin-bottom: 5px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            color: #595959;
        }

        .section2 {
            width: 100%;
            height: 50px;
            font-family: calibri;
            background-color: #7E97AD;
            color: #fff;
        }

        .h2-section2 {
            margin-left: 20px;
            line-height: 50px;
        }

        .section3 {
            margin-top: 10px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table td,
        table th {
            border: 1px solid #ddd;
            padding: 8px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }

        table th {
            background-color: #5a5c69;
            color: #fff;
            text-align: left;
        }

        tr:nth-child(even) {
            background: #E5EAEE;
        }
    </style>
</head>

<body>
    <section class="section1">
        <a href="/laporan/penjualan/semua/download" target="_blank"><button type="button">Download</button></a>
        <h3>REKAPITULASI TRANSAKSI PENJUALAN BARANG</h3>
    </section>

    <section class="section3">
        <table>
            <tr>
                <th>NO</th>
                <th>NO INVOICE</th>
                <th>PELANGGAN</th>
                <th>TOTAL PEMBAYARAN</th>
                <th>POTONGAN</th>
                <th>PEMBAYARAN</th>
                <th>KEMBALIAN</th>
                <th>JENIS PEMBAYARAN</th>
                <th>JENIS BANK</th>
                <th>BIAYA PENGIRIMAN</th>
                <th>SUB TOTAL</th>
            </tr>
            <?php
            $no = 1;
            $total_penjualan = 0;
            ?>
            <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><a href="" target="_blank"><?php echo e($item->no_invoice); ?></a></td>
                <td><?php echo e($item->pelanggan_id); ?></td>
                <td><?php echo e(number_format($item->total_pembayaran, 0, ',', '.')); ?></td>
                <td><?php echo e(number_format($item->diskon, 0, ',', '.')); ?></td>
                <td><?php echo e(number_format($item->pembayaran, 0, ',', '.')); ?></td>
                <td><?php echo e(number_format($item->kembalian, 0, ',', '.')); ?></td>
                <td><?php echo e(strtoupper($item->jenis)); ?></td>
                <td><?php echo e(strtoupper($item->jenis_bank)); ?></td>
                <td><?php echo e(number_format($item->biaya_pengiriman, 0, ',', '.')); ?></td>
                <td><?php echo e(number_format($item->sub_total, 0, ',', '.')); ?></td>
            </tr>
            <?php
            $total_penjualan += $item->sub_total;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="10">Total Penjualan</td>
                <td><?php echo e(number_format($total_penjualan, 0, ',', '.')); ?></td>
            </tr>
        </table>
    </section>
</body>

</html><?php /**PATH E:\laravel\pos-rash\resources\views/laporan/penjualan_semua.blade.php ENDPATH**/ ?>