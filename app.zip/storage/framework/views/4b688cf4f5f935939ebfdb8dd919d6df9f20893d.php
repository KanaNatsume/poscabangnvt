

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Data <?php echo e($title); ?></h3>
                            <div class="card-tools">
                                <a href="/barang/create" class="btn btn-success btn-sm">
                                    <i class="fas fa-plus"></i> Tambah <?php echo e($title); ?> Baru
                                </a>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered table-striped table-hover table-sm" id="datatable">
                                <thead class="bg-primary">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Kategori</th>
                                        <th>Harga Beli</th>
                                        <th>Harga Ecer</th>
                                        <th>Harga Grosir</th>
                                        <th>Harga Agen</th>
                                        <th>Profit Harga Ecer</th>
                                        <th>Profit Harga Grosir</th>
                                        <th>Profit Harga Agen</th>
                                        <th>Stok</th>
                                        <th>Minimal Stok</th>
                                        <th>Deskripsi</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($item->kode_barang); ?></td>
                                        <td><?php echo e($item->nama_barang); ?></td>
                                        <td><?php echo e($item->kategori->nama); ?></td>
                                        <td><?php echo e(number_format($item->harga_beli, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->harga_ecer, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->harga_grosir, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->harga_agen, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->profit_harga_ecer, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->profit_harga_grosir, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->profit_harga_agen, 0, ',', '.')); ?></td>
                                        <td><?php echo e($item->stok); ?></td>
                                        <td><?php echo e($item->stok_minimal); ?></td>
                                        <td><?php echo e($item->deskripsi); ?></td>
                                        <td>
                                            <a href="/barang/<?php echo e($item->id); ?>/edit"
                                                class="btn btn-warning text-white btn-sm"><i class="fas fa-edit"></i>
                                                Edit</a>
                                            <a href="/barang/<?php echo e($item->id); ?>/destroy"
                                                onclick="return confirm('Yakin mau dihapus?!')"
                                                class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i>
                                                Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-rash\resources\views/barang/index.blade.php ENDPATH**/ ?>