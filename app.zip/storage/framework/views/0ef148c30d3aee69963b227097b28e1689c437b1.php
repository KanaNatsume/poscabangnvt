

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Laporan <?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Laporan <?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <form action="/laporan/keuntungan_minggu_atau_bulan_cari" method="get">
                                <div class="row">
                                    <div class="col-md-1">
                                        <label>Pilih Tanggal</label>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <input type="date" name="tanggal_awal" class="form-control form-control-sm"
                                                id="tanggal_awal" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <input type="date" name="tanggal_akhir" class="form-control form-control-sm"
                                                id="tanggal_akhir" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary">Cari</button>
                                        <a href="/laporan/keuntungan_minggu_atau_bulan"
                                            class="btn btn-primary">Refresh</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Tanggal : <?php echo e($tanggal_awal1); ?> Sampai <?php echo e($tanggal_akhir1); ?></strong>
                                </div>
                                <div class="col-md-6">
                                    <form action="/laporan/keuntungan_minggu_atau_bulan_download" method="post" target="
                                    _blank">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="tanggal_awal" value="<?php echo e($tanggal_awal2); ?>">
                                        <input type="hidden" name="tanggal_akhir" value="<?php echo e($tanggal_akhir2); ?>">
                                        <button type="submit" class="btn btn-success float-right">Download PDF</button>
                                    </form>
                                </div>
                            </div>
                            <table class="table table-bordered table-striped table-hover table-sm mt-2">
                                <thead class="bg-primary">
                                    <tr>
                                        <th>#</th>
                                        <th>Tanggal</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Jenis Penjualan</th>
                                        <th>Harga</th>
                                        <th>QTY</th>
                                        <th>Profit</th>
                                        <th>Potongan</th>
                                        <th>Keuntungan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $total_keuntungan = 0;
                                    ?>
                                    <?php $__currentLoopData = $detail_penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $keuntungan = $item->qty * $item->profit - $item->potongan;
                                    $total_keuntungan += $keuntungan;
                                    ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e(date('d-m-Y H:i:s', strtotime($item->created_at))); ?></td>
                                        <td><?php echo e($item->kode_barang); ?></td>
                                        <td><?php echo e($item->nama_barang); ?></td>
                                        <td><?php echo e(strtoupper($item->jenis)); ?></td>
                                        <td><?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e(number_format($item->profit, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->potongan, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($keuntungan, 0, ',', '.')); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="9" align="center"><strong>Total Keuntungan</strong></td>
                                        <td><?php echo e(number_format($total_keuntungan, 0, ',', '.')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            <p><strong>Rumus Keuntungan :</strong> QTY X Profit - Potongan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bisnisna/pos.preneur.co.id/resources/views/laporan/keuntungan_minggu_atau_bulan_cari.blade.php ENDPATH**/ ?>