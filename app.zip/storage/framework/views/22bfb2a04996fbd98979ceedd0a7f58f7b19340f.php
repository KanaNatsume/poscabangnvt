

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Data <?php echo e($title); ?></h3>
                            <div class="card-tools">
                                <a href="/retur/tambah/<?php echo e(no_retur()); ?>" class="btn btn-success">
                                    <i class="fas fa-plus"></i> Tambah <?php echo e($title); ?> Baru
                                </a>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered table-striped table-hover table-sm" id="datatable">
                                <thead class="bg-primary">
                                    <tr>
                                        <th>#</th>
                                        <th>No Retur</th>
                                        <th>Pelanggan</th>
                                        <th>Total Pembayaran</th>
                                        <th>Pembayaran</th>
                                        <th>Kembalian</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $retur_barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($item->no_retur); ?></td>
                                        <td><?php echo e($item->pelanggan->nama); ?></td>
                                        <td><?php echo e(number_format($item->total_pembayaran, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->pembayaran, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->kembalian, 0, ',', '.')); ?></td>
                                        <td><?php echo e(tanggal_indonesia(date('d-m-Y', strtotime($item->created_at)))); ?></td>
                                        <td>
                                            <a href="/retur/detail/<?php echo e($item->id); ?>"
                                                class="btn btn-secondary text-white btn-sm" target="_blank"><i
                                                    class="fas fa-paper-plane"></i>
                                                Detail</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bisnisna/pos.preneur.co.id/resources/views/return_barang/index.blade.php ENDPATH**/ ?>