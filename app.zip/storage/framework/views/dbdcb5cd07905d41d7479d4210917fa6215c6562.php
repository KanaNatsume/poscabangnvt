

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper">

    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard v1</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>
                                Rp. <span id="penjualan">0</span>
                            </h3>
                            <p>Penjualan Hari Ini</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3>
                                Rp. <span id="profit">0</span>
                            </h3>
                            <p>Profit Hari Ini</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-stats-bars"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>
                                <span id="supplier">0</span>
                            </h3>
                            <p>Total Supplier</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-truck"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3>
                                <span id="barang">0</span>
                            </h3>
                            <p>Total Barang</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-list"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Grafik Stok Data Barang</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="myChart" width="400" height="150"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php if(session('forbidden')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'warning',
          title: "<?php echo e(session('forbidden')); ?>"
        })
    });  
</script>
<?php endif; ?>

<script>
    setInterval(function () {
        $.ajax({
            url: '/dashboard/penjualan',
            type: 'get',
            success: function (result) {
                let UbahFormat = result.penjualan;
                let	reverse = UbahFormat.toString().split('').reverse().join(''),
                    ribuan 	= reverse.match(/\d{1,3}/g);
                    ribuan	= ribuan.join('.').split('').reverse().join('');
                $("#penjualan").html(ribuan);
            }
        });
    }, 1000);

    setInterval(function () {
        $.ajax({
            url: '/dashboard/profit',
            type: 'get',
            success: function (result) {
                let UbahFormat = result.profit;
                let	reverse = UbahFormat.toString().split('').reverse().join(''),
                    ribuan 	= reverse.match(/\d{1,3}/g);
                    ribuan	= ribuan.join('.').split('').reverse().join('');
                $("#profit").html(ribuan);
            }
        });
    }, 1000);

    setInterval(function () {
        $.ajax({
            url: '/dashboard/supplier',
            type: 'get',
            success: function (result) {
                $('#supplier').html(result.supplier);
            }
        });
    }, 1000);

    setInterval(function () {
        $.ajax({
            url: '/dashboard/barang',
            type: 'get',
            success: function (result) {
                $('#barang').html(result.barang);
            }
        });
    }, 1000);
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.3.0/chart.min.js"
    integrity="sha512-yadYcDSJyQExcKhjKSQOkBKy2BLDoW6WnnGXCAkCoRlpHGpYuVuBqGObf3g/TdB86sSbss1AOP4YlGSb6EKQPg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Ketersediaan stok',
                    data: [],
                    fill: false,
                    borderColor: 'rgb(0, 123, 255)',
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        setInterval(function () {
            $.ajax({
                url: '/dashboard/chart',
                type: 'get',
                success: function (result) {
                    myChart.data.labels = result.labels;
                    myChart.data.datasets[0].data = result.data;
                    myChart.update();
                }
            });
        }, 1000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>