

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Laporan <?php echo e($title); ?></h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Semua Data</th>
                                    <td><a href="/laporan/penjualan/semua" class="btn btn-secondary btn-sm"
                                            target="_blank"><i class="fas fa-eye"></i>
                                            View</a>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Pertanggal</th>
                                    <td>
                                        <form action="/laporan/penjualan/pertanggal" method="get" target="_blank">
                                            <div class="form-group">
                                                <label for="tanggal_awal">Dari Tanggal</label>
                                                <input type="date" name="tanggal_awal"
                                                    class="form-control form-control-sm" id="tanggal_awal" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tanggal_akhir">Sampai Tanggal</label>
                                                <input type="date" name="tanggal_akhir"
                                                    class="form-control form-control-sm" id="tanggal_akhir" required>
                                            </div>
                                            <button type="submit" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-eye"></i> View</button>
                                        </form>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Perbarang</th>
                                    <td>
                                        <form action="/laporan/penjualan/perbarang" method="get" target="_blank">
                                            <div class="form-group">
                                                <label for="kode_barang">Pilih Barang</label>
                                                <select name="kode_barang" id="kode_barang"
                                                    class="form-control select2bs4" required>
                                                    <option value="">Pilih</option>
                                                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->kode_barang); ?>">
                                                        <?php echo e($item->kode_barang); ?> - <?php echo e($item->nama_barang); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="tanggal_awal">Dari Tanggal</label>
                                                <input type="date" name="tanggal_awal"
                                                    class="form-control form-control-sm" id="tanggal_awal" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tanggal_akhir">Sampai Tanggal</label>
                                                <input type="date" name="tanggal_akhir"
                                                    class="form-control form-control-sm" id="tanggal_akhir" required>
                                            </div>
                                            <button type="submit" class="btn btn-secondary btn-sm"><i
                                                    class="fas fa-eye"></i> View</button>
                                        </form>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script>
    $(function () {  
        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })  
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-laravel-pak-fazar\resources\views/laporan/penjualan.blade.php ENDPATH**/ ?>