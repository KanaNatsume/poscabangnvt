<!DOCTYPE html>
<html lang="en">

<head>
    <title>Struk</title>
    <style>
        body {
            font-family: arial;
        }

        .container {
            width: 25%;
            min-height: 400px;
            border: 1px dashed #ddd;
        }


        .tagline {
            text-align: center;
            font-size: 12px;
            margin-top: -15px;
        }

        tr:nth-child(even) {
            background-color: #ddd;
        }

        @media  print { 
            @page  { width: 80mm; margin: 0mm }
        }
    </style>
</head>

<body onload="window.print()">

    <div class="container">
        <h2 align="center">LaraMart</h2>
        <p class="tagline">Jl. Raya Singaparna Tasikmalaya</p>

        <table border="1" cellspacing="0" align="center" width="90%" style="font-size: 12px">
            <tr>
                <td><strong> Tanggal</strong></td>
                <td align="right"><?php echo e(date('d-m-y')); ?></td>
            </tr>
            <tr>
                <td><strong> Kasir</strong></td>
                <td align="right"><?php echo e(auth()->user()->name); ?></td>
            </tr>
            <tr>
                <td><strong> No Invoice</strong></td>
                <td align="right"><?php echo e(request()->segment(3)); ?></td>
            </tr>
        </table>

        <table border="1" cellspacing="0" align="center" width="90%" style="font-size: 12px; margin-top: 20px;">
            <tr>
                <td colspan="7"><strong>Detail Pembelian</strong></td>
            </tr>
            <tr>
                <td><strong> No</strong></td>
                <td><strong> Nama</strong></td>
                <td><strong> Harga</strong></td>
                <td><strong> Qty</strong></td>
                <td><strong> Total Harga</strong></td>
            </tr>
            <?php
            $no = 1;
            ?>
            <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($item->nama); ?></td>
                <td><?php echo e(rupiah($item->harga_jual)); ?></td>
                <td><?php echo e($item->qty); ?></td>
                <td><?php echo e(rupiah($item->total_harga)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="4"><strong>Pembayaran</strong></td>
                <td><?php echo e(rupiah($detail_penjualan->pembayaran)); ?></td>
            </tr>
            <tr>
                <td colspan="4"><strong>Total Pembayaran</strong></td>
                <td><?php echo e(rupiah($detail_penjualan->total_pembayaran)); ?></td>
            </tr>
            <tr>
                <td colspan="4"><strong>Kembalian</strong></td>
                <td><?php echo e(rupiah($detail_penjualan->kembalian)); ?></td>
            </tr>
        </table>

        <p style="text-align: center; font-size: 12px; margin-top: 50px">Barang yang rusak bisa dikembalikan lagi dengan
            syarat tertentu.
        </p>
        <p style="text-align: center; font-size: 12px;">--- Terima Kasih ---</p>
    </div>

</body>

</html><?php /**PATH E:\laravel\pos-laravel\resources\views/penjualan/struk.blade.php ENDPATH**/ ?>